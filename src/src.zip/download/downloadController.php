<?php
class Download
{
    public function excel($e)
    {
        echo "<script>$(document).ready(
            function(){
                  document.location.href='template_IPL.xlsx'; 

                
            }
        )</script>";
    }
}
